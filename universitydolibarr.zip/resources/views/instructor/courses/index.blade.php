<x-app-layout> 
    @livewire('instructor.course-index')
</x-app-layout>