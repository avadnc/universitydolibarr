var primary = localStorage.getItem("primary") || '#7e37d8';
var secondary = localStorage.getItem("secondary") || '#1ea6ec';

window.pocoAdminConfig = {
	// Theme Primary Color
	primary: primary,
	// theme secondary color
	secondary: secondary,
};